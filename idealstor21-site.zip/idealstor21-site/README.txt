سایت فروشگاه ایده‌آل — راهنمای انتشار رایگان

فایل اصلی سایت: index.html

برای انتشار در GitHub Pages:
1. وارد github.com شوید و وارد حساب خود شوید.
2. روی علامت + بزنید و New repository را انتخاب کنید.
3. نام مخزن را idealstor21 بگذارید و آن را Public کنید؛ سپس Create repository.
4. در مخزن روی Add file و سپس Upload files بزنید.
5. فایل index.html را بارگذاری کنید و Commit changes را بزنید.
6. وارد Settings > Pages شوید.
7. در بخش Build and deployment، گزینه Deploy from a branch را انتخاب کنید.
8. Branch را روی main و پوشه را روی /(root) قرار دهید و Save کنید.
9. پس از چند دقیقه، آدرس سایت در همان صفحه نمایش داده می‌شود؛ معمولاً https://نام‌کاربری.github.io/idealstor21/

نکته: نام‌کاربری گیت‌هاب شما تعیین می‌کند آدرس دقیق چه باشد. این فایل هنوز به اینترنت منتشر نشده است؛ مراحل بالا برای انتشار لازم‌اند.
